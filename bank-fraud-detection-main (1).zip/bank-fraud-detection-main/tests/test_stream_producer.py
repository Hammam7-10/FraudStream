import json

from src.seed_data import build_data
from src.stream_producer import json_value
from src.settings import FEATURE_COLUMNS
from src.xgb_predictor import XGBoostJSONModel


def test_stream_transaction_is_valid_json():
    row = build_data("mixed")[0]
    encoded = json.dumps(row, default=json_value)
    decoded = json.loads(encoded)
    assert decoded["transaction_id"] == row["transaction_id"]
    assert decoded["timestamp"].endswith("+00:00")
    assert len([key for key in decoded if key.startswith("V")]) == 28


def test_exported_model_detects_known_fraud_pattern():
    row = build_data("model")[-2]
    model = XGBoostJSONModel("pipeline.xgb.json")
    assert model.predict([row[column] for column in FEATURE_COLUMNS]) > 0.99
