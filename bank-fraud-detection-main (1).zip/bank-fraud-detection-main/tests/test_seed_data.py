from src.seed_data import build_data
from src.settings import FEATURE_COLUMNS

def test_demo_data_contains_expected_scenarios_and_model_features():
    rows = build_data()
    assert len(rows) == 121
    assert sum(r["scenario"] == "large_amount" for r in rows) == 2
    assert sum(r["scenario"] == "rapid_repeat_6" for r in rows) == 6
    assert sum(r["scenario"] == "rapid_repeat_4" for r in rows) == 4
    assert sum(r["scenario"] == "model_prediction" for r in rows) == 1
    assert all(feature in rows[0] for feature in FEATURE_COLUMNS)
