import os

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DATABASE = os.getenv("MONGO_DATABASE", "fraud_detection")
APP_DB_PATH = os.getenv("APP_DB_PATH", "/app/data/fraud.db")
KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "bank-transactions")
HDFS_RAW_PATH = os.getenv("HDFS_RAW_PATH", "hdfs://localhost:9000/fraud/raw-transactions")
HDFS_CHECKPOINT_PATH = os.getenv("HDFS_CHECKPOINT_PATH", "hdfs://localhost:9000/fraud/checkpoints/stream")
STREAM_TRIGGER_SECONDS = int(os.getenv("STREAM_TRIGGER_SECONDS", "5"))
SIMULATION_INTERVAL_SECONDS = float(os.getenv("SIMULATION_INTERVAL_SECONDS", "0.2"))
AMOUNT_THRESHOLD = float(os.getenv("AMOUNT_THRESHOLD", "10000"))
VELOCITY_WINDOW_MINUTES = int(os.getenv("VELOCITY_WINDOW_MINUTES", "10"))
VELOCITY_TRANSACTION_LIMIT = int(os.getenv("VELOCITY_TRANSACTION_LIMIT", "4"))
MODEL_THRESHOLD = float(os.getenv("MODEL_THRESHOLD", "0.65"))
# The supplied XGBoost model was trained on V1..V28 and Amount (29 columns).
FEATURE_COLUMNS = [f"V{i}" for i in range(1, 29)] + ["Amount"]
