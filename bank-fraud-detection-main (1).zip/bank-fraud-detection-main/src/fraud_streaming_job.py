"""Spark Structured Streaming: Kafka -> Spark/ML -> HDFS + MongoDB."""
import sys
from datetime import datetime
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import DoubleType, StringType, StructField, StructType, TimestampType
from pyspark.sql.window import Window

from src.settings import (
    AMOUNT_THRESHOLD,
    FEATURE_COLUMNS,
    HDFS_CHECKPOINT_PATH,
    HDFS_RAW_PATH,
    KAFKA_BOOTSTRAP_SERVERS,
    KAFKA_TOPIC,
    MODEL_THRESHOLD,
    STREAM_TRIGGER_SECONDS,
    VELOCITY_TRANSACTION_LIMIT,
    VELOCITY_WINDOW_MINUTES,
)
from src.storage import save_stream_batch
from src.xgb_predictor import XGBoostJSONModel


def transaction_schema():
    fields = [
        StructField("transaction_id", StringType()),
        StructField("customer_id", StringType()),
        StructField("timestamp", TimestampType()),
        StructField("merchant", StringType()),
        StructField("country", StringType()),
        StructField("channel", StringType()),
        StructField("scenario", StringType()),
    ]
    fields.extend(StructField(column, DoubleType()) for column in FEATURE_COLUMNS)
    return StructType(fields)


def main():
    spark = SparkSession.builder.appName("BankFraudStreaming").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    model = XGBoostJSONModel(Path(__file__).resolve().parents[1] / "pipeline.xgb.json")

    source = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVERS)
        .option("subscribe", KAFKA_TOPIC)
        .option("startingOffsets", "earliest")
        .option("failOnDataLoss", "false")
        .load()
    )
    transactions = (
        source.select(F.from_json(F.col("value").cast("string"), transaction_schema()).alias("tx"))
        .select("tx.*")
        .where(F.col("transaction_id").isNotNull())
    )

    def process_batch(batch, batch_id):
        if batch.limit(1).count() == 0:
            return
        batch = batch.persist()
        batch.write.mode("append").partitionBy("country").parquet(HDFS_RAW_PATH)

        seconds = VELOCITY_WINDOW_MINUTES * 60
        timed = batch.withColumn("event_seconds", F.col("timestamp").cast("long"))
        window = Window.partitionBy("customer_id").orderBy("event_seconds").rangeBetween(-seconds, 0)
        scored = (
            timed.withColumn("transactions_in_window", F.count("transaction_id").over(window))
            .withColumn("large_amount", F.col("Amount") >= F.lit(AMOUNT_THRESHOLD))
            .withColumn("velocity_flag", F.col("transactions_in_window") >= F.lit(VELOCITY_TRANSACTION_LIMIT))
        )
        scored_rows = [row.asDict(recursive=True) for row in scored.toLocalIterator()]
        transaction_rows = [{key: value for key, value in row.items()
                             if key not in ("event_seconds", "large_amount", "velocity_flag",
                                            "transactions_in_window")}
                            for row in scored_rows]
        alert_rows = []
        for row in scored_rows:
            probability = model.predict([float(row[column]) for column in FEATURE_COLUMNS])
            model_flag = probability >= MODEL_THRESHOLD
            if not (row["large_amount"] or row["velocity_flag"] or model_flag):
                continue
            reasons = []
            if row["large_amount"]:
                reasons.append("مبلغ أكبر من الحد")
            if model_flag:
                reasons.append("النموذج التنبؤي")
            if row["velocity_flag"]:
                reasons.append("تكرار سريع للعمليات")
            risk = "critical" if probability >= 0.85 else (
                "high" if row["large_amount"] or row["velocity_flag"] else "medium")
            alert_rows.append({
                "transaction_id": row["transaction_id"], "customer_id": row["customer_id"],
                "timestamp": row["timestamp"], "Amount": row["Amount"],
                "model_score": probability, "transaction_count": row["transactions_in_window"],
                "reasons": " | ".join(reasons), "alert_kind": "stream",
                "risk_level": risk, "processed_at": datetime.utcnow(),
            })
        save_stream_batch(transaction_rows, alert_rows, batch_id)
        batch.unpersist()
        print(f"batch={batch_id} transactions={len(transaction_rows)} alerts={len(alert_rows)}", flush=True)

    query = (
        transactions.writeStream.foreachBatch(process_batch)
        .option("checkpointLocation", HDFS_CHECKPOINT_PATH)
        .trigger(processingTime=f"{STREAM_TRIGGER_SECONDS} seconds")
        .start()
    )
    query.awaitTermination()


if __name__ == "__main__":
    main()
