"""Generate demonstrable transaction data and load it into MongoDB."""
import argparse
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4
from typing import Dict, List, Optional

import numpy as np

sys.path.append(str(Path(__file__).resolve().parents[1]))
from src.settings import MONGO_DATABASE, MONGO_URI

DATASET_INFO = {
    "mixed": {"name": "حالات مختلطة", "description": "طبيعية، مبالغ كبيرة، تكرار، ونموذج تنبؤي", "count": 121},
    "normal_only": {"name": "معاملات طبيعية", "description": "90 معاملة سليمة للتحقق من عدم ظهور إنذارات كاذبة", "count": 90},
    "high_value": {"name": "مبالغ كبيرة", "description": "5 معاملات بمبالغ مرتفعة مع معاملات طبيعية", "count": 81},
    "velocity": {"name": "تكرار سريع", "description": "ثلاثة عملاء لديهم 4 و6 و8 عمليات خلال 10 دقائق", "count": 103},
    "model": {"name": "اختبار النموذج", "description": "حالات عالية الخطورة يكتشفها نموذج XGBoost", "count": 84},
}


def record(customer_id, at, amount, scenario="normal", feature_override=None):
    features = {f"V{i}": round(float(np.random.normal(0, 1)), 6) for i in range(1, 29)}
    if feature_override:
        features.update(feature_override)
    return {
        "transaction_id": str(uuid4()), "customer_id": customer_id,
        "timestamp": at, "Time": int(at.timestamp()), "Amount": round(amount, 2),
        "merchant": random.choice(["متجر إلكتروني", "سوبرماركت", "محطة وقود", "صيدلية"]),
        "country": random.choice(["YE", "SA", "AE"]), "channel": random.choice(["card", "web", "mobile"]),
        "scenario": scenario, **features,
    }


def model_feature_override():
    values = [-2.374995, 11.256486, -2.538336, 5.798811, 11.194537, -11.518766,
              -9.065211, 17.365965, -2.515389, -4.950627, 8.429726, -12.559426,
              -6.251909, -16.343372, 15.959958, -16.148909, -7.830135, -18.434303,
              -16.538891, -17.513159, 3.338595, -3.143907, -12.957487, 6.119072,
              -4.340055, 12.830410, -8.447296, -10.799328]
    return {f"V{i}": value for i, value in enumerate(values, start=1)}


def add_normal(rows, count, now):
    for i in range(count):
        rows.append(record(f"C{1000 + i % 27}", now - timedelta(minutes=30 + i * 7),
                           max(5, np.random.lognormal(4.2, 0.55)), "normal"))


def add_velocity_group(rows, customer_id, count, interval, now):
    for i in range(count):
        rows.append(record(customer_id, now - timedelta(minutes=i * interval), 95 + i * 18,
                           f"rapid_repeat_{count}"))


def build_data(preset="mixed"):
    if preset not in DATASET_INFO:
        raise ValueError(f"Unknown preset: {preset}")
    random.seed(42 + list(DATASET_INFO).index(preset)); np.random.seed(42 + list(DATASET_INFO).index(preset))
    now = datetime.now(timezone.utc).replace(microsecond=0)
    rows = []
    if preset == "normal_only":
        add_normal(rows, 90, now)
    elif preset == "high_value":
        add_normal(rows, 76, now)
        for i, amount in enumerate([11000, 14500, 18000, 25000, 42000]):
            rows.append(record(f"C91{i}", now - timedelta(minutes=i * 3), amount, "large_amount"))
    elif preset == "velocity":
        add_normal(rows, 85, now)
        add_velocity_group(rows, "C9201", 4, 2, now)
        add_velocity_group(rows, "C9202", 6, 1, now)
        add_velocity_group(rows, "C9203", 8, 1, now)
    elif preset == "model":
        add_normal(rows, 80, now)
        for i in range(3):
            rows.append(record(f"C930{i}", now - timedelta(minutes=i * 4), 555.84 + i,
                               "model_prediction", model_feature_override()))
        rows.append(record("C9309", now - timedelta(minutes=12), 22000, "large_amount"))
    else:  # mixed
        add_normal(rows, 108, now)
        rows.extend([record("C9001", now - timedelta(minutes=2), 25000, "large_amount"),
                     record("C9003", now - timedelta(minutes=4), 14500, "large_amount")])
        add_velocity_group(rows, "C9002", 6, 1, now)
        add_velocity_group(rows, "C9004", 4, 2, now)
        rows.append(record("C9005", now - timedelta(minutes=7), 555.84, "model_prediction",
                           model_feature_override()))
    return rows


def load_dataset(preset, reset=True):
    from pymongo import MongoClient
    db = MongoClient(MONGO_URI)[MONGO_DATABASE]
    if reset:
        db.transactions.drop(); db.fraud_alerts.drop()
    rows = build_data(preset)
    db.transactions.insert_many(rows)
    db.transactions.create_index("transaction_id", unique=True)
    db.transactions.create_index([("customer_id", 1), ("timestamp", 1)])
    return len(rows)


if __name__ == "__main__":
    from pymongo import MongoClient
    parser = argparse.ArgumentParser(); parser.add_argument("--reset", action="store_true")
    parser.add_argument("--preset", choices=DATASET_INFO, default="mixed")
    args = parser.parse_args()
    total = load_dataset(args.preset, reset=args.reset)
    print(f"Inserted {total} transactions from '{args.preset}' into {MONGO_DATABASE}.transactions")
