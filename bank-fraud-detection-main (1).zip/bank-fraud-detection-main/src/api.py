from pathlib import Path
import sys
import threading
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, PlainTextResponse

sys.path.append(str(Path(__file__).resolve().parents[1]))
from src.settings import (AMOUNT_THRESHOLD, FEATURE_COLUMNS, KAFKA_BOOTSTRAP_SERVERS,
                          KAFKA_TOPIC, MODEL_THRESHOLD, SIMULATION_INTERVAL_SECONDS,
                          STREAM_TRIGGER_SECONDS, VELOCITY_TRANSACTION_LIMIT,
                          VELOCITY_WINDOW_MINUTES)
from src.seed_data import DATASET_INFO, build_data
from src.storage import connection, reset_transactions
from src.stream_producer import create_producer, publish_dataset, publish_record

app = FastAPI(title="نظام كشف الاحتيال المالي")
simulation_lock = threading.Lock()
simulation_stop = threading.Event()
simulation_thread = None
simulation_state = {
    "running": False, "preset": None, "published": 0, "round": 0,
    "interval_seconds": SIMULATION_INTERVAL_SECONDS, "started_at": None,
    "last_event_at": None, "error": None,
}


def run_simulation(preset, interval):
    producer = None
    try:
        producer = create_producer()
        while not simulation_stop.is_set():
            rows = build_data(preset)
            with simulation_lock:
                simulation_state["round"] += 1
            for row in rows:
                if simulation_stop.is_set():
                    break
                publish_record(producer, row).get(timeout=10)
                now = datetime.now(timezone.utc).isoformat()
                with simulation_lock:
                    simulation_state["published"] += 1
                    simulation_state["last_event_at"] = now
                simulation_stop.wait(interval)
    except Exception as exc:
        with simulation_lock:
            simulation_state["error"] = str(exc)
    finally:
        if producer:
            producer.flush(timeout=15)
            producer.close(timeout=5)
        with simulation_lock:
            simulation_state["running"] = False


@app.get("/")
def home():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


@app.get("/api/documentation", response_class=PlainTextResponse)
def documentation():
    return (Path(__file__).resolve().parents[1] / "docs" / "PROJECT.md").read_text(encoding="utf-8")


@app.get("/api/project-info")
def project_info():
    return {
        "project": {
            "name": "منظومة رصد الاحتيال البنكي",
            "type": "Big Data Streaming Academic Demo",
            "pipeline": ["Kafka", "Spark Structured Streaming", "XGBoost", "Hadoop HDFS"],
            "kafka_partitions": 3,
            "stream_trigger_seconds": STREAM_TRIGGER_SECONDS,
            "simulation_rate_per_second": round(1 / SIMULATION_INTERVAL_SECONDS, 1),
        },
        "model": {
            "algorithm": "XGBoost Classifier", "features": len(FEATURE_COLUMNS),
            "estimators": 400, "max_depth": 4, "learning_rate": 0.1637,
            "decision_threshold": MODEL_THRESHOLD, "objective_metric": "AUC-PR",
            "demo_accuracy": 1.0, "demo_validation_samples": 83,
            "accuracy_note": "النتيجة على مجموعة التحقق التجريبية للمشروع وليست مقياس إنتاجي.",
        },
        "rules": {
            "amount_threshold": AMOUNT_THRESHOLD,
            "velocity_limit": VELOCITY_TRANSACTION_LIMIT,
            "velocity_window_minutes": VELOCITY_WINDOW_MINUTES,
        },
    }


@app.get("/api/summary")
def summary():
    with connection() as database:
        total = database.execute("SELECT count(*) FROM transactions").fetchone()[0]
        alerts = database.execute("SELECT count(*) FROM fraud_alerts").fetchone()[0]
        levels = dict(database.execute(
            "SELECT risk_level, count(*) FROM fraud_alerts GROUP BY risk_level").fetchall())
    return {"total_transactions": total, "alerts": alerts, "by_level": levels,
            "alert_rate": round((alerts / total * 100), 2) if total else 0}


@app.get("/api/alerts")
def alerts(limit: int = 50):
    with connection() as database:
        rows = database.execute(
            """SELECT transaction_id, customer_id, timestamp, amount AS Amount, model_score,
                      transaction_count, reasons, alert_kind, risk_level, processed_at
               FROM fraud_alerts ORDER BY timestamp DESC LIMIT ?""", (min(limit, 200),)).fetchall()
        return [dict(row) for row in rows]


@app.get("/api/datasets")
def datasets():
    return [{"id": key, **value} for key, value in DATASET_INFO.items()]


@app.post("/api/simulation/start/{preset}")
def start_simulation(preset: str):
    global simulation_thread
    if preset not in DATASET_INFO:
        raise HTTPException(status_code=404, detail="سيناريو المحاكاة غير موجود")
    with simulation_lock:
        if simulation_state["running"]:
            return {**simulation_state, "message": "المحاكاة تعمل بالفعل"}
        reset_transactions([])
        simulation_stop.clear()
        simulation_state.update({
            "running": True, "preset": preset, "published": 0, "round": 0,
            "interval_seconds": SIMULATION_INTERVAL_SECONDS,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "last_event_at": None, "error": None,
        })
        simulation_thread = threading.Thread(
            target=run_simulation, args=(preset, SIMULATION_INTERVAL_SECONDS),
            name="kafka-simulator", daemon=True)
        simulation_thread.start()
        return {**simulation_state, "message": "بدأت محاكاة تدفق المعاملات"}


@app.post("/api/simulation/stop")
def stop_simulation():
    simulation_stop.set()
    with simulation_lock:
        return {**simulation_state, "message": "جارٍ إيقاف المحاكاة"}


@app.get("/api/simulation/status")
def simulation_status():
    with simulation_lock:
        return dict(simulation_state)


@app.post("/api/datasets/{preset}/load")
def load_preset(preset: str):
    if preset not in DATASET_INFO:
        raise HTTPException(status_code=404, detail="مجموعة البيانات غير موجودة")
    try:
        rows = build_data(preset)
        reset_transactions(rows)
        total = len(rows)
        return {"message": "تم تحميل البيانات بنجاح", "preset": preset, "transactions": total,
                "next_step": "شغّل تحليل Spark لتحديث التنبيهات."}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"تعذر الوصول إلى MongoDB: {exc}") from exc


@app.post("/api/stream/{preset}/publish")
def publish_preset(preset: str):
    if preset not in DATASET_INFO:
        raise HTTPException(status_code=404, detail="مجموعة البيانات غير موجودة")
    try:
        total = publish_dataset(preset, interval=0)
        return {"message": "تم إرسال المعاملات إلى Kafka", "topic": KAFKA_TOPIC,
                "transactions": total}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"تعذر النشر إلى Kafka: {exc}") from exc


@app.get("/api/pipeline")
def pipeline_status():
    with connection() as database:
        row = database.execute(
            "SELECT * FROM pipeline_runs WHERE component='spark-stream'").fetchone()
    return {"mode": "streaming", "kafka_topic": KAFKA_TOPIC,
            "kafka_brokers": KAFKA_BOOTSTRAP_SERVERS, "spark": dict(row) if row else {}}


@app.get("/health")
def health():
    try:
        with connection() as database:
            database.execute("SELECT 1").fetchone()
        return {"status": "ok"}
    except Exception as exc:
        return {"status": "storage_error", "detail": str(exc)}
