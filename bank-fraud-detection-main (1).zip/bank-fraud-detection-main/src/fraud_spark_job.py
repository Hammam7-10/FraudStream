"""Spark batch job: rules + the supplied XGBoost model, results back to MongoDB."""
import os
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))
from src.settings import (AMOUNT_THRESHOLD, FEATURE_COLUMNS, MODEL_THRESHOLD,
                          MONGO_DATABASE, MONGO_URI, VELOCITY_TRANSACTION_LIMIT,
                          VELOCITY_WINDOW_MINUTES)

from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import DoubleType
from pyspark.sql.window import Window


def mongo_options(collection: str) -> dict:
    # Connector v10 supports connection.uri and collection/database separately.
    return {"connection.uri": MONGO_URI, "database": MONGO_DATABASE, "collection": collection}


def main():
    spark = SparkSession.builder.appName("FinancialFraudDetection").getOrCreate()
    tx = spark.read.format("mongodb").options(**mongo_options("transactions")).load()
    if tx.rdd.isEmpty():
        print("No transactions found; run seed_data.py first."); return

    # Count a customer's transactions in the preceding configured time range.
    seconds = VELOCITY_WINDOW_MINUTES * 60
    timed = tx.withColumn("event_seconds", F.col("timestamp").cast("long"))
    window = Window.partitionBy("customer_id").orderBy("event_seconds").rangeBetween(-seconds, 0)
    scored = timed.withColumn("transactions_in_window", F.count("transaction_id").over(window))
    scored = scored.withColumn("large_amount", F.col("Amount") >= F.lit(AMOUNT_THRESHOLD))

    # The supplied model uses 29 numerical fields (V1..V28, Amount).
    model_path = str(Path(__file__).resolve().parents[1] / "pipeline.joblib")
    import joblib
    model = joblib.load(model_path)
    broadcast_model = spark.sparkContext.broadcast(model)

    @F.pandas_udf(DoubleType())
    def fraud_probability(*columns):
        import pandas as pd
        matrix = pd.concat(columns, axis=1).astype(float)
        matrix.columns = FEATURE_COLUMNS
        return pd.Series(broadcast_model.value.predict_proba(matrix)[:, 1])

    scored = scored.withColumn("model_score", fraud_probability(*[F.col(c) for c in FEATURE_COLUMNS]))
    scored = scored.withColumn("model_flag", F.col("model_score") >= F.lit(MODEL_THRESHOLD))
    transaction_reasons = F.concat_ws(" | ",
        F.when(F.col("large_amount"), F.lit("مبلغ أكبر من الحد")),
        F.when(F.col("model_flag"), F.lit("النموذج التنبؤي")),
    )
    # Amount/model alerts remain per transaction. A velocity incident is deliberately
    # aggregated to one alert per customer, including every transaction in that burst.
    transaction_alerts = (scored.where(F.col("large_amount") | F.col("model_flag"))
        .select("transaction_id", "customer_id", "timestamp", "Amount", "model_score",
                F.lit(1).alias("transaction_count"), transaction_reasons.alias("reasons"),
                F.lit("transaction").alias("alert_kind"),
                F.when(F.col("model_score") >= .85, "critical").when(F.col("large_amount"), "high")
                 .otherwise("medium").alias("risk_level")))

    velocity_alerts = (scored.groupBy("customer_id")
        .agg(F.count("transaction_id").alias("transaction_count"),
             F.sum("Amount").alias("Amount"), F.max("timestamp").alias("timestamp"),
             F.min("event_seconds").alias("first_event_seconds"),
             F.max("event_seconds").alias("last_event_seconds"), F.max("model_score").alias("model_score"))
        .where((F.col("transaction_count") >= F.lit(VELOCITY_TRANSACTION_LIMIT)) &
               ((F.col("last_event_seconds") - F.col("first_event_seconds")) <= F.lit(seconds)))
        .select(F.concat(F.lit("velocity:"), F.col("customer_id")).alias("transaction_id"), "customer_id",
                "timestamp", "Amount", "model_score", "transaction_count",
                F.concat(F.lit("اشتباه: تكرار "), F.col("transaction_count").cast("string"),
                         F.lit(f" عمليات خلال {VELOCITY_WINDOW_MINUTES} دقائق")).alias("reasons"),
                F.lit("velocity").alias("alert_kind"), F.lit("high").alias("risk_level")))

    alerts = (transaction_alerts.unionByName(velocity_alerts)
              .withColumn("processed_at", F.current_timestamp()))
    alerts.write.format("mongodb").mode("overwrite").options(**mongo_options("fraud_alerts")).save()
    print(f"Created {alerts.count()} fraud alerts.")
    spark.stop()


if __name__ == "__main__":
    main()
