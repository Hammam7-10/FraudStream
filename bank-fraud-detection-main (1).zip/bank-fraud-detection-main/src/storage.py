"""Small shared metadata store for the demo dashboard and streaming driver."""
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(os.getenv("APP_DB_PATH", "/app/data/fraud.db"))


def connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id TEXT PRIMARY KEY, customer_id TEXT, timestamp TEXT,
            amount REAL, payload TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS fraud_alerts (
            transaction_id TEXT PRIMARY KEY, customer_id TEXT, timestamp TEXT,
            amount REAL, model_score REAL, transaction_count INTEGER,
            reasons TEXT, alert_kind TEXT, risk_level TEXT, processed_at TEXT
        );
        CREATE TABLE IF NOT EXISTS pipeline_runs (
            component TEXT PRIMARY KEY, batch_id INTEGER, records INTEGER,
            status TEXT, updated_at TEXT
        );
    """)
    return conn


def serializable(document):
    return {key: (value.isoformat() if isinstance(value, datetime) else value)
            for key, value in document.items()}


def save_stream_batch(transactions, alerts, batch_id):
    with connection() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO transactions VALUES (?, ?, ?, ?, ?)",
            [(row["transaction_id"], row["customer_id"], str(row["timestamp"]), row["Amount"],
              json.dumps(serializable(row), ensure_ascii=False)) for row in transactions],
        )
        conn.executemany(
            "INSERT OR REPLACE INTO fraud_alerts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [(row["transaction_id"], row["customer_id"], str(row["timestamp"]), row["Amount"],
              row["model_score"], row["transaction_count"], row["reasons"], row["alert_kind"],
              row["risk_level"], str(row["processed_at"])) for row in alerts],
        )
        conn.execute(
            "INSERT OR REPLACE INTO pipeline_runs VALUES ('spark-stream', ?, ?, 'running', ?)",
            (batch_id, len(transactions), datetime.now(timezone.utc).isoformat()),
        )


def reset_transactions(rows):
    with connection() as conn:
        conn.execute("DELETE FROM transactions")
        conn.execute("DELETE FROM fraud_alerts")
        conn.execute("DELETE FROM pipeline_runs")
        conn.executemany(
            "INSERT INTO transactions VALUES (?, ?, ?, ?, ?)",
            [(row["transaction_id"], row["customer_id"], row["timestamp"].isoformat(), row["Amount"],
              json.dumps(serializable(row), ensure_ascii=False)) for row in rows],
        )
