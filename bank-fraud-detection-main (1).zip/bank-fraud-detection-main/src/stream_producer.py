"""Publish synthetic bank transactions to Kafka as a real-time stream."""
import argparse
import json
import time
from datetime import datetime

from kafka import KafkaProducer

from src.seed_data import DATASET_INFO, build_data
from src.settings import KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC


def json_value(value):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(f"Unsupported JSON value: {type(value)!r}")


def create_producer():
    return KafkaProducer(
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS.split(","),
        value_serializer=lambda row: json.dumps(row, default=json_value).encode("utf-8"),
        acks="all",
        retries=5,
    )


def publish_record(producer, row):
    return producer.send(
        KAFKA_TOPIC, key=row["customer_id"].encode("utf-8"), value=row)


def publish_dataset(preset="mixed", interval=0.15):
    """Publish one deterministic demo dataset and wait for broker acknowledgements."""
    producer = create_producer()
    rows = build_data(preset)
    for row in rows:
        publish_record(producer, row)
        if interval:
            time.sleep(interval)
    producer.flush(timeout=30)
    producer.close(timeout=10)
    return len(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preset", choices=DATASET_INFO, default="mixed")
    parser.add_argument("--interval", type=float, default=0.15)
    parser.add_argument("--loop", action="store_true")
    parser.add_argument("--pause", type=float, default=20)
    args = parser.parse_args()
    while True:
        total = publish_dataset(args.preset, args.interval)
        print(f"Published {total} records to {KAFKA_TOPIC}", flush=True)
        if not args.loop:
            break
        time.sleep(args.pause)


if __name__ == "__main__":
    main()
