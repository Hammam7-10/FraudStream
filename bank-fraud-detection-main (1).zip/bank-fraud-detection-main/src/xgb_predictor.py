"""Dependency-free inference for the exported XGBoost tree model."""
import json
import math
from pathlib import Path


class XGBoostJSONModel(object):
    def __init__(self, path):
        with Path(path).open(encoding="utf-8") as handle:
            learner = json.load(handle)["learner"]
        self.trees = learner["gradient_booster"]["model"]["trees"]
        base_score = float(learner["learner_model_param"]["base_score"])
        self.base_margin = math.log(base_score / (1.0 - base_score))

    def predict(self, features):
        margin = self.base_margin
        for tree in self.trees:
            node = 0
            while tree["left_children"][node] != -1:
                feature_index = tree["split_indices"][node]
                value = features[feature_index]
                if value is None or (isinstance(value, float) and math.isnan(value)):
                    go_left = bool(tree["default_left"][node])
                else:
                    go_left = value < tree["split_conditions"][node]
                node = tree["left_children"][node] if go_left else tree["right_children"][node]
            margin += tree["split_conditions"][node]
        return 1.0 / (1.0 + math.exp(-margin))
